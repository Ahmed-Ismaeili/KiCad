# atmega2560_core
Kicad schematic for Atmega 2560. This includes the most basic elements to create a project with Atmega 2560 (Arduino Mega).

## Kicad version
Kicad >=4.0 required 

## Design 
This design only includes the most basic elements to work with the microcontroller Atmega 2560. This design is being used in Regadiu project (www.regadiu.com).

It includes JTAG and SPI for debug and program the microcontroller.
